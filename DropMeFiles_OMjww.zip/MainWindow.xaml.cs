﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddPassengerCar_Click(object sender, RoutedEventArgs e)
        {
            var car = new PassengerCar { Brand = "Toyota", Model = "Camry", Year = 2022, NumberOfSeats = 5 };
            CarListBox.Items.Add(car.GetInfo());
        }

        private void AddTruck_Click(object sender, RoutedEventArgs e)
        {
            var truck = new Truck { Brand = "Volvo", Model = "FH", Year = 2021, LoadCapacity = 15000 };
            CarListBox.Items.Add(truck.GetInfo());
        }

        private void AddBus_Click(object sender, RoutedEventArgs e)
        {
            var bus = new Bus { Brand = "Mercedes", Model = "Sprinter", Year = 2020, NumberOfPassengers = 20 };
            CarListBox.Items.Add(bus.GetInfo());
        }
    }
}
