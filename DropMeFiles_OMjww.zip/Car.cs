﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarApp
{
    public class Car
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }

        public virtual string GetInfo()
        {
            return $"{Brand} {Model}, Year: {Year}";
        }
    }

    public class Truck : Car
    {
        public int LoadCapacity { get; set; }

        public override string GetInfo()
        {
            return base.GetInfo() + $", Load Capacity: {LoadCapacity} kg";
        }
    }

    public class PassengerCar : Car
    {
        public int NumberOfSeats { get; set; }

        public override string GetInfo()
        {
            return base.GetInfo() + $", Seats: {NumberOfSeats}";
        }
    }

    public class Bus : Car
    {
        public int NumberOfPassengers { get; set; }

        public override string GetInfo()
        {
            return base.GetInfo() + $", Passengers: {NumberOfPassengers}";
        }
    }
}

